METEORS20 by Fabrizio Caruso

Original game by Fabrizio Caruso

GAMEPLAY:
You are in outer space.
You must avoid the falling meteors "*".
As you advance the number of meteors increases.

You can activate a limited number of barriers to destroy the all objects next to you.

3 types of bonus items fall and catching them provides extra points that can help reach
the next 1000 points. If you do, you are awared an extra life (max 9) and will restore the max number of barriers.

SCORE:
- Points increase automaticaly as you progress: 1 point at each step
- Common bonus item yellow "$": 20 points
- Less common bonus item cyan "diamand": 50 points
- Rare bonus item red "club": 100 points

CONTROLS:
Use: J (left), L (right) to move
Use: SPACE BAR to activate the barrier


