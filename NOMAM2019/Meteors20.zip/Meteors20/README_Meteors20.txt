METEORS20 by Fabrizio Caruso

Original game by Fabrizio Caruso

GAMEPLAY:
You are in outer space.
You must avoid the falling meteors "*".
You can activate a BARRIER (press SPACE) to destroy the all objects next to you.
You have a limited number of barriers (max 9).

As you advance the number of meteors increases.

3 types of bonus items fall and catching them provides extra points.

If you reach the next 1000 points, you are awared:
- an extra life (up to max 9 lives) and 
- max barriers (back to 9)

SCORE:
- Points increase automaticaly as you progress: 1 point at each step
- (Common) item yellow "$": 20 points
- (Less common) item cyan "diamand": 50 points
- (Rare) item red "clubs": 100 points

CONTROLS:
Use: J (left), L (right) to move
Use: SPACE BAR to activate the barrier

STATUS LINE:
On the top line, the game shows the following status line:
no. of lives (red), no. of barriers (purple), points (white), high score (white), current level (green)


