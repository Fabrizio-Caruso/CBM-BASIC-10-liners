THIEF64 by Fabrizio Caruso

Original game idea by Fabrizio Caruso

You are a thief chased by 8 guards.
The guards use a non-trivial (pseudo-intelligent) strategy that depends on both you absolute position
and your relative position with respect to the guards.
You must steal dollars "$" that appear at the center of the screen.

As the game starts and you move on the screen, the guards will appear and start chasing you.

You can stun the guards for a few seconds by using your stunning bombs (you only have 9).

You must avoid the guards and not touch the wall.

Every other 4 stolen "$", the side borders will shrink and make your life harder.

SCORE:
1 point per stolen "$" 

CONTROLS:
Use: I J K L to move
USE: SPACE to stun the guards