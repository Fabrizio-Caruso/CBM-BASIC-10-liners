MINIMANS20 by Fabrizio Caruso

Game idea by Fabrizio Caruso, inspired (somehow) by Le Mans for (by Commodore for the C64)

GAMEPLAY:
You race on a road crammed with cars during alternating cycles of day and night.
You have to avoid the cars, the road borders and the trees.
Hitting a car or the road borders will add 1 damage to your car (at 9 you it is game over).
If you hit a tree, you are instantly dead.
At night, the border is not clearly visible but the headlights of your car can let you perceive the border of the road if you are next to it.
Differently from Le Mans, MiniMans has an end.

SCORE:
Points increase as you progress.

CONTROLS:
Use J (left), L (right)
