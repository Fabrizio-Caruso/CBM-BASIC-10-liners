MINIMANS20 by Fabrizio Caruso

Game idea by Fabrizio Caruso, inspired (somehow) by Le Mans for (by Commodore for the C64)

GAMEPLAY:
You race on a road crammed with cars during alternating cycles of day and night.
At night, the borders of road are not visible but the HEADLIGHTS of your car can let you perceive them if close enough.
You have to avoid the cars, the road borders and the trees.
Hitting a car or the road borders will add damage your car (you can survive only 8 hits).
If you hit a tree, you are instantly dead.
Differently from the game "Le Mans", MiniMans has an end.

SCORE:
Points increase as you progress.

CONTROLS:
Use J (left), L (right)
